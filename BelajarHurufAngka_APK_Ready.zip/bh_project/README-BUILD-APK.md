# Belajar Huruf & Angka — Build APK

Project ini sudah dilengkapi GitHub Actions. Setelah project di-upload ke repository GitHub pada branch `main` atau `master`, GitHub akan otomatis membangun APK debug.

## Cara mendapatkan APK
1. Upload seluruh isi project ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih workflow **Build APK**.
4. Tunggu sampai status menjadi hijau/berhasil.
5. Buka hasil workflow tersebut.
6. Pada bagian **Artifacts**, pilih **BelajarHurufAngka-APK**.
7. Download ZIP artifact dan ambil `app-debug.apk` di dalamnya.
8. Pasang APK di HP Android. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

Workflow juga dapat dijalankan manual dari **Actions → Build APK → Run workflow**.
